RegisterCommand('darkmagic', function(source)
    if source == 0 then return end
    if IsPlayerAceAllowed(source, 'darkmagic.use') then
        TriggerClientEvent('darkmagic:toggle', source)
    end
end, false)

RegisterCommand('darkmagicoff', function(source)
    if source == 0 then return end
    if IsPlayerAceAllowed(source, 'darkmagic.use') then
        TriggerClientEvent('darkmagic:forceoff', source)
    end
end, false)
